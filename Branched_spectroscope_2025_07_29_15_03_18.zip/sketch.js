function setup() {
  createCanvas(4000, 4000);
}

function draw() {
  background(255,182,193);
}